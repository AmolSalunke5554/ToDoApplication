﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using ToDoWebApi.Controllers;
using ToDoWebApi.Modules;
using ToDoWebApi.Service;

namespace ToDoWebApi.Test
{
    public class ControllerTestCase
    {
        private readonly ILogger<HomeController> _logger;       
        private readonly Mock<ITodoServiceList> _mockRepo;
        private readonly HomeController _controller;

        public ControllerTestCase()
        {

            _mockRepo = new Mock<ITodoServiceList>();
            _controller = new HomeController(_mockRepo.Object);
          
        }

        /// <summary>
        /// Controller Get
        /// </summary>
        /// 
        [Fact]
        public void GetById_TodoExists_ReturnsOkResultWithToDo()
        {
            // Arrange
            var mockService = new Mock<ITodoServiceList>();
            mockService.Setup(s => s.GetById(1))
                       .Returns(new ToDoItem { Id = 1, Name = "Task Updated", Status = "Completed", Priority = 1 });

            var controller = new HomeController(mockService.Object);

            // Act
            var result = controller.GetById(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var user = Assert.IsType<ToDoItem>(okResult.Value);
            Assert.Equal("Task Updated", user.Name);
        }


        [Fact]
        public void GetById_TodoDoesNotExist_ReturnsNotFound()
        {
            // Arrange
            var mockService = new Mock<ITodoServiceList>();
            mockService.Setup(s => s.GetById(4)).Returns((ToDoItem)null);

            var controller = new HomeController(mockService.Object);

            // Act
            var result = controller.GetById(4);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }



        [Fact]
        public void GetBlogs_GetAction_MustReturnOkObjectResult()
        {


            // Arrange
            var blogsServiceMock = new Mock<ITodoServiceList>();



            var _items = new List<ToDoItem>()
            {
                new ToDoItem { Id = 1, Name = "Task Updated", Status = "Completed", Priority = 1 },
                new ToDoItem { Id = 2, Name = "task update", Status = "Inprocess", Priority = 2 },
                new ToDoItem { Id = 3, Name = "task delete", Status = "Start", Priority = 2 }
            };

            blogsServiceMock.Setup(e => e.GetList()).Returns(_items);

            var controller = new HomeController(blogsServiceMock.Object);

            // Act
            var result = controller.GetAll();

            // Assert
            var actionResult = Assert.IsAssignableFrom<ActionResult<IEnumerable<ToDoItem>>>(result);
            var okObjectResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var dtos = Assert.IsAssignableFrom<IEnumerable<ToDoItem>>(okObjectResult.Value);
            Assert.Equal(3, dtos.Count());
        }


        /// <summary>
        /// 
        /// </summary>

        [Fact]
        public void Add_Should_Return_Correct_Details()
        {
            var mockService = new Mock<ITodoServiceList>();
            var feedback = new ToDoFeedback();
            //var feedback = new ToDoFeedback { Success = true, Message = "Details Added" };
            var item = new ToDoItem { Id = 5, Name = "Task Updated 5", Status = "Completed", Priority = 1 };
            mockService.Setup(s => s.CreateTodo(item))
                       .Returns(feedback);

            var controller = new HomeController(mockService.Object);

            // Act
            var result = controller.CreateTodo(item);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var user = Assert.IsType<ToDoFeedback>(okResult.Value);
            Assert.True(user.Success);
        }


        [Fact]
        public void Addwith_Incomplete_Name_Inputs()
        {
            var mockService = new Mock<ITodoServiceList>();
            //var feedback = new ToDoFeedback();
           var feedback = new ToDoFeedback { Success = false, Message = "Incomplete Details" };
            var item = new ToDoItem { Id = 6, Name = "", Status = "Completed", Priority = 1 };
            mockService.Setup(s => s.CreateTodo(item))
                       .Returns(feedback);

            var controller = new HomeController(mockService.Object);

            // Act
            var result = controller.CreateTodo(item);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var user = Assert.IsType<ToDoFeedback>(okResult.Value);
            Assert.False(user.Success);
        }


        [Fact]
        public void AddWith_Incomplete_Name_Status_Inputs_ReturnsBadRequest()
        {
            // Arrange
            var mockService = new Mock<ITodoServiceList>();
            var controller = new HomeController(mockService.Object);

            // Create an invalid ToDoItem (e.g., missing Title if it's required)
            var incompleteItem = new ToDoItem { Id = 6, Name = "", Status = "", Priority = 1 };

            // Force model state error
            controller.ModelState.AddModelError("Title", "The Name field is required.");
            controller.ModelState.AddModelError("Title", "The Status field is required.");

            // Act
            var result = controller.CreateTodo(incompleteItem);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.IsType<SerializableError>(badRequestResult.Value); 
        }


        /// <summary>
        /// update
        /// </summary>

        [Fact]
        public void Update_TodoNotExists_ReturnsNoContent()
        {
            // Arrange
            var feedback = new ToDoFeedback { Success = true, Message = "ToDo Not Found" };

            var mockService = new Mock<ITodoServiceList>();
            var ToDoToUpdate = new ToDoItem { Id = 4, Name = "Task Updated", Status = "Completed", Priority = 1 };

            mockService.Setup(s => s.UpdateTodo(ToDoToUpdate)).Returns(feedback);

            var controller = new HomeController(mockService.Object);

            // Act
            var result = controller.Update(ToDoToUpdate);

            // Assert

            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var value = Assert.IsType<ToDoFeedback>(okResult.Value);
            Assert.Equal("ToDo Not Found", value.Message);
        }

        [Fact]
        public void Update_TodoWithIncorrect_Details_ReturnsNoContent()
        {
            // Arrange
            var mockService = new Mock<ITodoServiceList>();
            var controller = new HomeController(mockService.Object);

            // Create an invalid ToDoItem (e.g., missing Title if it's required)
            var incompleteItem = new ToDoItem { Id = 1, Name = "", Status = "", Priority = 1 };

            // Force model state error
            controller.ModelState.AddModelError("Name", "The Name field is required.");
            controller.ModelState.AddModelError("Status", "The Status field is required.");

            // Act
            var result = controller.CreateTodo(incompleteItem);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.IsType<SerializableError>(badRequestResult.Value);
        }



        [Fact]
        public void Delete_ValidId_ReturnsOkWithFeedback()
        {
            var feedback = new ToDoFeedback { Success = true, Message = "Deleted" };
            var mock = new Mock<ITodoServiceList>();
            mock.Setup(s => s.DeleteTodo(1)).Returns(feedback);

            var controller = new HomeController(mock.Object);

            var result = controller.DeleteById(1);

            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var value = Assert.IsType<ToDoFeedback>(okResult.Value);
            Assert.Equal("Deleted", value.Message);
        }
        [Fact]
        public void Delete_NegativeId_ReturnsOkWithFeedback()
        {
            var feedback = new ToDoFeedback { Success = true, Message = "Invalid Id" };
            var mock = new Mock<ITodoServiceList>();
            mock.Setup(s => s.DeleteTodo(-1)).Returns(feedback);

            var controller = new HomeController(mock.Object);

            var result = controller.DeleteById(-1);

            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var value = Assert.IsType<ToDoFeedback>(okResult.Value);
            Assert.Equal("Invalid Id", value.Message);
        }


        [Fact]
        public void Delete_InvalidId_ReturnsWithFeedback()
        {
            var feedback = new ToDoFeedback { Success = true, Message = "Not Deleted" };
            var mock = new Mock<ITodoServiceList>();
            mock.Setup(s => s.DeleteTodo(99)).Returns(feedback);

            var controller = new HomeController(mock.Object);

            var result = controller.DeleteById(99);

            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var value = Assert.IsType<ToDoFeedback>(okResult.Value);
            Assert.Equal("Not Deleted", value.Message);
        }


    }
}

