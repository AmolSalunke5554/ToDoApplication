using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using ToDoWebApi.Controllers;
using ToDoWebApi.Modules;
using ToDoWebApi.Service;
namespace ToDoWebApi.Test
{
    public class ServiceTestCase
    {
        private readonly ILogger<HomeController> _logger;
        private readonly TodoService _ToDoRepository;
        private readonly Mock<ITodoServiceList> _mockRepo;
        private readonly HomeController _controller;

        public ServiceTestCase()
        {

            _mockRepo = new Mock<ITodoServiceList>();
            _controller = new HomeController(_mockRepo.Object);
            _ToDoRepository = new TodoService();
        }

        /// <summary>
        /// Get 
        /// </summary>
        /// 

        [Fact]
        public void Get_ToDo_ById_ReturnsNullWhenToDotaskNotFound()
        {

            var todoId = 99;
            var result = _ToDoRepository.GetById(todoId);
            Assert.Null(result);
        }

        [Fact]
        public void GetAlltodo_ReturnsAlltodo()
        {
            var result = _ToDoRepository.GetList();
            Assert.NotNull(result);
            Assert.Equal(3, result.Count());
        }



        [Fact]
        public void Get_ToDoById_ReturnsCorrectToDo()
        {
            var userId = 1;
            var result = _ToDoRepository.GetById(userId);
            Assert.NotNull(result);
            Assert.Equal(userId, result.Id);
        }
        [Fact]
        public void Get_ToDoById_InvalidId()
        {
            var todoId = -1;
            var result = _ToDoRepository.GetById(todoId);
            Assert.Null(result);
        }


        [Fact]
        public void ModelValidation_InvalidData_ReturnsValidationErrors()
        {
            // Arrange
            var newtodo = new ToDoItem { Id = 4, Name = "", Status = "", Priority = 0 };
            var validationContext = new ValidationContext(newtodo);
            var validationResults = new List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(newtodo, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.True(validationResults.Any());
        }

        /// <summary>
        /// Create Task
        /// </summary>

        [Fact]
        public void Addtodo_AddtodoCorrectly()
        {

            var newtodo = new ToDoItem { Id = 4, Name = "Task Creation", Status = "Completed", Priority = 3 };

            _ToDoRepository.CreateTodo(newtodo);
            var result = _ToDoRepository.GetById(4);
            Assert.NotNull(result);
            Assert.Equal(newtodo.Id, result.Id);
            Assert.Equal(newtodo.Name, result.Name);
            Assert.Equal(newtodo.Status, result.Status);
            Assert.Equal(newtodo.Priority, result.Priority);
        }
        [Fact]
        public void AddTodo_with_no_priority()
        {

            var newtodo = new ToDoItem { Id = 4, Name = "Task Creation", Status = "Completed" };
            var validationContext = new ValidationContext(newtodo);
            var validationResults = new List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(newtodo, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Equal("ToDo Priority is Invalid", validationResults[0].ErrorMessage);
        }
        [Fact]
        public void AddTodo_with_SameName()
        {

            var newtodo = new ToDoItem { Id = 4, Name = "Task Updated", Status = "Completed", Priority = 1 };
           var status= _ToDoRepository.CreateTodo(newtodo);
            //var result = _ToDoRepository.GetById(4);
            Assert.NotNull(status);
            Assert.Equal("Task Name already exist", status.Message);
            
        }

        [Fact]
        public void AddTodo_NameWithBlankSpace()
        {

            var newtodo = new ToDoItem { Id = 4, Name = "Task Updated ", Status = "Completed", Priority = 1 };
            var status = _ToDoRepository.CreateTodo(newtodo);
            //var result = _ToDoRepository.GetById(4);
            Assert.NotNull(status);
            Assert.Equal("Task Name already exist", status.Message);

        }

        [Fact]
        public void AddTodo_with_no_Status()
        {

            var newtodo = new ToDoItem { Id = 4, Name = "Task Creation", Status = "", Priority = 1 };
            var validationContext = new ValidationContext(newtodo);
            var validationResults = new List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(newtodo, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Equal("ToDo Status is required", validationResults[0].ErrorMessage);
        }



        [Fact]
        public void AddAsync_ShouldFail_WhenTask_Id_Name_Status_Blank()
        {
            var task = new ToDoItem { Name = "", Status = "", Priority = 1 };

            //var ex =  _ToDoRepository.CreateTodo(task);
            //Assert.Equal("Task name is required", ex.Message);

            var validationContext = new ValidationContext(task);
            var validationResults = new List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(task, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Equal("Name must be between 5 and 100 characters.", validationResults[0].ErrorMessage);
            Assert.Equal("ToDo Status is required", validationResults[1].ErrorMessage);



        }

        [Fact]
        public void Add_ShouldFail_WhenTaskNameIsEmpty()
        {
            var task = new ToDoItem { Name = "", Status = "Start", Priority = 1 };

            //var ex = _ToDoRepository.CreateTodo(task);
            //Assert.Equal("Task name is required", ex.Message);
            var validationContext = new ValidationContext(task);
            var validationResults = new List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(task, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Equal("Name must be between 5 and 100 characters.", validationResults[0].ErrorMessage);
        }

        


        /// <summary>
        /// Update
        /// </summary>
        [Fact]
        public void Updatetodo_With_Correct_Details()
        {

            var updatedUser = new ToDoItem { Id = 1, Name = "Task Updated", Status = "Start", Priority = 2 };

            _ToDoRepository.UpdateTodo(updatedUser);
            var result = _ToDoRepository.GetById(1);

            Assert.NotNull(result);
            Assert.Equal(updatedUser.Name, result.Name);
            Assert.Equal(updatedUser.Status, result.Status);
            Assert.Equal(updatedUser.Priority, result.Priority);
        }

        [Fact]
        public void UpdateToDo_ShouldFail_WhenTask_Status_Is_Diffrent()
        {

            var updatedUser = new ToDoItem { Id = 1, Name = "Task Updated", Status = "Okays", Priority = 2 };

            _ToDoRepository.UpdateTodo(updatedUser);
            var result = _ToDoRepository.GetById(1);

            Assert.NotNull(result);
            Assert.NotEqual(updatedUser.Status, result.Status);

        }

        [Fact]
        public void UpdateToDo_ShouldFail_WhenTaskNamelessthen5char()
        {

            var updatedTask = new ToDoItem { Id = 1, Name = "Task", Status = "Start", Priority = 2 };

            //var ex = _ToDoRepository.CreateTodo(task);
            //Assert.Equal("Task name is required", ex.Message);
            var validationContext = new ValidationContext(updatedTask);
            var validationResults = new List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(updatedTask, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Equal("Name must be between 5 and 100 characters.", validationResults[0].ErrorMessage);

        }



        [Fact]
        public void UpdateToDo_ShouldFail_WhenTaskStatusIs_Diffrentfromlist()
        {

            var updatedUser = new ToDoItem { Id = 1, Name = "Task Updated", Status = "ABC", Priority = 2 };

           var result= _ToDoRepository.UpdateTodo(updatedUser);
           // var result = _ToDoRepository.GetById(1);

            Assert.NotNull(result);
            Assert.Equal("Task Status is Not Valid.", result.Message);

        }

        [Fact]
        public void Updatetodo_WithSameName()
        {

            var updatedUser = new ToDoItem { Id = 2, Name = "task update", Status = "Completed", Priority = 1 };

            _ToDoRepository.UpdateTodo(updatedUser);
            var result = _ToDoRepository.GetById(2);

            Assert.NotNull(result);
            Assert.Equal(updatedUser.Name, result.Name);

        }
        [Fact]
        public void Updatetodo_Update_ToDo_WithSameName_Diffrent_Status()
        {

            var updatedUser = new ToDoItem { Id = 2, Name = "task update", Status = "Start", Priority = 1 };

            _ToDoRepository.UpdateTodo(updatedUser);
            var result = _ToDoRepository.GetById(2);

            Assert.NotNull(result);
            Assert.Equal(updatedUser.Name, result.Name);
            Assert.Equal(updatedUser.Status, result.Status);

        }
        [Fact]
        public void Updatetodo_Update_ToDo_WithSameName_Invalid_Priority()
        {
            var newtodo = new ToDoItem { Id = 2, Name = "task update", Status = "Start", Priority = 0 };
            var validationContext = new ValidationContext(newtodo);
            var validationResults = new List<ValidationResult>();

            // Act
            bool isValid = Validator.TryValidateObject(newtodo, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Equal("ToDo Priority is Invalid", validationResults[0].ErrorMessage);


        }

        /// <summary>
        /// Delete
        /// </summary>
        [Fact]
        public void Deletetodo_Delete_Correctly()
        {
            var userId = 3;
            _ToDoRepository.DeleteTodo(userId);
            var result = _ToDoRepository.GetById(userId);

            Assert.Null(result);
        }

        [Fact]
        public void Deletetodo_ShouldFailed_WhenTaskNotFound()
        {
            var userId = 99;
            var result = _ToDoRepository.DeleteTodo(userId);
            Assert.Equal("Task not found.", result.Message);
        }



        [Fact]
        public void DeleteAsync_ShouldReturnFalse_WhenIdIsInvalid()
        {
            var userId = -1;
            var result = _ToDoRepository.DeleteTodo(userId);
            Assert.Equal("Invalid task id.", result.Message);
        }
    }
}