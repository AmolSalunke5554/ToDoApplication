﻿using ToDoWebApi.Modules;

namespace ToDoWebApi.Service
{
    public interface ITodoServiceList
    {
        IEnumerable<ToDoItem> GetList();
        ToDoItem GetById(int id);
        ToDoFeedback CreateTodo(ToDoItem item);
        ToDoFeedback UpdateTodo(ToDoItem item);
        ToDoFeedback DeleteTodo(int id);

    }
}
