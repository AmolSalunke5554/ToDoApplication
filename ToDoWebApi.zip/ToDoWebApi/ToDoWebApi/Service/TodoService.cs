﻿using System.Diagnostics.Eventing.Reader;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web.Http.ModelBinding;
using Microsoft.AspNetCore.Mvc;
using ToDoWebApi.Modules;




namespace ToDoWebApi.Service
{
    public class TodoService : ITodoServiceList
    {
        private List<ToDoItem> _items;
        private readonly ILogger<TodoService> _logger;



        public TodoService()
        {
            _items = new List<ToDoItem>()
            {
                new ToDoItem { Id = 1, Name = "Task Updated", Status = "Completed", Priority = 1 },
                new ToDoItem { Id = 2, Name = "task update", Status = "Inprocess", Priority = 2 },
                new ToDoItem { Id = 3, Name = "task delete", Status = "Start", Priority = 2 }
            };
        }
        public ToDoFeedback CreateTodo(ToDoItem item)
        {

            var FeedbackResponse = new ToDoFeedback();
            FeedbackResponse.ValidationErrors = new List<string>();
            bool status = Enum.IsDefined(typeof(Status), item.Status);
            var Item = _items.FirstOrDefault(t => t.Name.Trim() == item.Name.Trim());

            if (status != false)
            {
                if (Item == null)
                {
                    int LNumber = _items.Max(r => r.Id);
                    var product = new ToDoItem
                    {
                        Id = LNumber + 1,
                        Name = item.Name.Trim(),
                        Status = item.Status,
                        Priority = item.Priority,
                    };
                    _items.Add(product);
                    FeedbackResponse.ToDoItem = product;
                    FeedbackResponse.Success = true;
                }
                else
                {
                    FeedbackResponse.Success = false;
                    FeedbackResponse.Message = "Task Name already exist";
                }
            }
            else
            {
                FeedbackResponse.Message = "Task name is required";
                FeedbackResponse.Success = false;
            }

            return FeedbackResponse;
        }

        public ToDoFeedback DeleteTodo(int id)
        {
            var FeedbackResponse = new ToDoFeedback();
            FeedbackResponse.ValidationErrors = new List<string>();
            if (id > 0)
            {
                var todo = GetByTodoId(id);
                if (todo != null)
                {
                    _items.Remove(todo);
                    //FeedbackResponse.ToDoItem = todo;
                    FeedbackResponse.Success = true;
                }
                else
                {
                    FeedbackResponse.Success = false;
                    FeedbackResponse.Message = "Task not found.";
                }
            }
            else
            {
                FeedbackResponse.Success = false;
                FeedbackResponse.Message = "Invalid task id.";
            }

            return FeedbackResponse;
        }

        public ToDoItem? GetByTodoId(int id)
        {
            ToDoItem? item = _items.FirstOrDefault(e => e.Id == id);
            return item;
        }

        public ToDoItem? GetById(int id)
        {

            //var Item = _items.FirstOrDefault(p => p.Id == id);
            //if (Item == null) return null;

            //return new ToDoItem
            //{
            //    Id = Item.Id,
            //    Name = Item.Name,
            //    Status = Item.Status,
            //    Priority = Item.Priority               
            //};
            ToDoItem? item = _items.FirstOrDefault(e => e.Id == id);
            return item;
        }

        public IEnumerable<ToDoItem> GetList()
        {
            return _items.Select(p => new ToDoItem
            {
                Id = p.Id,
                Name = p.Name,
                Status = p.Status,
                Priority = p.Priority
            }).ToList();
           
        }

        public ToDoFeedback UpdateTodo(ToDoItem item)
        {
            var FeedbackResponse = new ToDoFeedback();
            FeedbackResponse.ValidationErrors = new List<string>();
            bool status = Enum.IsDefined(typeof(Status), item.Status);
            if (status != false)
            {

                var todo = GetByTodoId(item.Id);
                if (todo != null)
                {
                    todo.Status = item.Status;
                    todo.Priority = item.Priority;
                    FeedbackResponse.ToDoItem = todo;
                }
                else
                {
                    FeedbackResponse.Success = false;
                    FeedbackResponse.Message = "Task not found.";
                }

            }
            else
            {
                FeedbackResponse.Message = "Task Status is Not Valid.";
                FeedbackResponse.Success = false;
            }


            return FeedbackResponse;
        }


    }
}
