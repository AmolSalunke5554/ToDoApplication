﻿using System.ComponentModel.DataAnnotations;

namespace ToDoWebApi.Modules
{
    public class ToDoItem:ToDoId
    {

      

        [StringLength(100, MinimumLength = 5, ErrorMessage = "Name must be between 5 and 100 characters.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "ToDo Status is required")]
        public string Status { get; set; } = string.Empty;

        [Required(ErrorMessage = "ToDo Priority is Required")]
        [Range(1, 3, ErrorMessage = "ToDo Priority is Invalid")]
        public int Priority { get; set; }

    }
}
