﻿namespace ToDoWebApi.Modules
{
    public enum Status
    {
        Start,
        Inprocess,
        Completed

    }
}
