﻿using ToDoWebApi.Responce;

namespace ToDoWebApi.Modules
{
    public class ToDoFeedback: BaseResponse
    {

        public ToDoFeedback() : base()
        {

        }

        public ToDoItem ToDoItem { get; set; }
    }
}
