﻿using System.ComponentModel.DataAnnotations;

namespace ToDoWebApi.Modules
{
    public class ToDoId
    {

        [Required(ErrorMessage = "ToDo id is required")]
        public int Id { get; set; }
    }
}
