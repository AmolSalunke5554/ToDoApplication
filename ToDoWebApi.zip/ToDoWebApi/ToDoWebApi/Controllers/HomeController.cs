﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ToDoWebApi.Modules;
using ToDoWebApi.Service;

namespace ToDoWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ITodoServiceList _todoServiceList;
        public HomeController( ITodoServiceList servicelist)
        {          
            _todoServiceList = servicelist;
        }

        [HttpGet("GetAll", Name = "get all detail")]
        public ActionResult<IEnumerable<ToDoItem>> GetAll()
        {
            return Ok(_todoServiceList.GetList());
        }

        
        [HttpGet("GetById", Name = "get By id detail")]
        public IActionResult GetById(int id)
        {
            var todolist=_todoServiceList.GetById(id);
            return todolist==null ? NotFound() : Ok(todolist);

        }
        [HttpPut("UpdateById", Name = "Update By id")]
        public ActionResult<ToDoFeedback> Update([FromBody] ToDoItem toDoItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var feedback = _todoServiceList.UpdateTodo(toDoItem);
            return feedback == null ? NotFound() : Ok(feedback);
         
            }

        [HttpPost("Create",Name ="Create todo")]
        public  ActionResult<ToDoFeedback> CreateTodo([FromBody] ToDoItem toDoItem)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var feedback =  _todoServiceList.CreateTodo(toDoItem);
            return feedback == null ? NotFound() : Ok(feedback);
            
        }

        [HttpDelete("DeletById",Name ="Delete By id")]
        public ActionResult<ToDoFeedback> DeleteById(int id)
        {

            var feedback = _todoServiceList.DeleteTodo(id);
            return feedback == null ? NotFound() : Ok(feedback);
            
        }




    }
}
